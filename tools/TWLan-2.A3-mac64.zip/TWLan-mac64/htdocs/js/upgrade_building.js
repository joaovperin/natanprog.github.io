<?php namespace Twlan; ?>
/* 23706 trunk*/
var UpgradeBuilding = {
    upgrade_buildings_enabled: false,
    possible_building_upgrades: null,
    get_possible_building_upgrades_link: null,
    upgrade_building_link: null,
    init: function(get_possible_building_upgrades_link, upgrade_building_link)
    {
        UpgradeBuilding.get_possible_building_upgrades_link = get_possible_building_upgrades_link;
        UpgradeBuilding.upgrade_building_link = upgrade_building_link;
        $('.label_no_lvl').hide();
        if ($.cookie('upgrade_buildings') != null) UpgradeBuilding.show_upgrade_buildings()
    },
    show_upgrade_buildings: function()
    {
        if (UpgradeBuilding.upgrade_buildings_enabled == true)
        {
            UpgradeBuilding.hide_upgrade_buildings();
            return
        };
        $.cookie('upgrade_buildings', 1);
        UpgradeBuilding.upgrade_buildings_enabled = true;
        if (UpgradeBuilding.possible_building_upgrades != null)
        {
            UpgradeBuilding._show_upgrade_buildings(UpgradeBuilding.possible_building_upgrades)
        }
        else $.getJSON(UpgradeBuilding.get_possible_building_upgrades_link,
        {}, UpgradeBuilding._show_upgrade_buildings)
    },
    _show_upgrade_buildings: function(ret)
    {
        UpgradeBuilding.possible_building_upgrades = ret;
        if (ret.buildings.lenght == 0) return false;
        $('.empty').hide();
        $.each(ret.buildings, function(building_id, needed_resources)
        {
            var building_label = $("#l_" + building_id),
                is_not_built = building_label.hasClass("label_no_lvl");
            building_label.show().find(".label").show();
            if (is_not_built)
            {
                var building_image = $('.cons_' + building_id);
                building_image.fadeTo("fast", 0.55)
            };
            var label = building_label.find(".label, .label_night").addClass("can_upgrade");
            if (!label) return false;
            var hammer = label.append('<img src="graphic/overview/build_big.png" style="display: inline;" id="hammer_' + building_id + '" class="upgrade_hammer" />').find('.upgrade_hammer'),
                new_title = UpgradeBuilding.generateResourcesLabel(needed_resources);
            label.attr("title", new_title);
            building_label.attr("title", '');
            UI.ToolTip(label);
            label.bind("click", function(e)
            {
                e.preventDefault();
                var handleConfirmQueue = function()
                {
                    $.ajax(
                    {
                        url: UpgradeBuilding.upgrade_building_link,
                        async: false,
                        dataType: 'json',
                        data:
                        {
                            id: building_id,
                            force: 1,
                            source: game_data.village.id
                        },
                        success: function(build_ret)
                        {
                            if (build_ret.error)
                            {
                                UI.ErrorMessage(build_ret.error)
                            }
                            else if (build_ret.success)
                            {
                                $('#l_main .building_extra').html(s('<span class="timer">%1</span>', build_ret.date_complete_formated));
                                $('#l_storage .building_extra').html(s('<span class="timer">%1</span>', build_ret.storage_full_time));
                                ret.confirm_queue = build_ret.confirm_queue;
                                if (is_not_built)
                                {
                                    building_image.fadeTo("normal", 1).removeClass('building_no_lvl');
                                    building_label.removeClass('label_no_lvl')
                                };
                                var upgrade_level_span = label.find('.building_order_level'),
                                    old_upgrade_level = parseInt(upgrade_level_span.text(), 10) || 0,
                                    new_upgrade_level = old_upgrade_level + 1;
                                upgrade_level_span.text((new_upgrade_level < 0 ? '-' : '+') + new_upgrade_level);
                                hammer.fadeOut(900, function()
                                {
                                    $(this).fadeIn(800);
                                    UpgradeBuilding.update_possible_upgrades(ret.buildings)
                                });
                                var $build_widget = $('#show_buildqueue').removeClass('hidden_widget').show(),
                                    $widget_content = $build_widget.find('.widget_content');
                                if (!$widget_content.length) $widget_content = $('<div class="widget_content" />').appendTo($build_widget);
                                $widget_content.html(build_ret.building_orders);
                                setRes('wood', build_ret.resources[0]);
                                setRes('stone', build_ret.resources[1]);
                                setRes('iron', build_ret.resources[2]);
                                $('#pop_current_label').html(build_ret.population);
                                startTimer()
                            }
                        }
                    })
                };
                if (!ret.confirm_queue)
                {
                    handleConfirmQueue();
                    return false
                };
                var msg = "Assignments added to the building queue will cost more. Do you still want to add this assignment?",
                    buttons = [
                    {
                        text: 'Confirm',
                        callback: handleConfirmQueue,
                        confirm: true
                    }];
                UI.ConfirmationBox(msg, buttons);
                return false
            })
        })
    },
    update_possible_upgrades: function(old_buildings)
    {
        $.getJSON(UpgradeBuilding.get_possible_building_upgrades_link,
        {}, function(ret)
        {
            UpgradeBuilding.possible_building_upgrades = ret;
            var new_buildings = ret.buildings;
            if (new_buildings.lenght == 0)
            {
                UpgradeBuilding.hide_upgrade_buildings();
                return false
            };
            $.each(old_buildings, function(building_id)
            {
                var label = $("#l_" + building_id).find(".label, .label_night");
                if (!new_buildings[building_id])
                {
                    label.removeClass("can_upgrade").unbind("click");
                    label.find('.upgrade_hammer').remove();
                    label.attr("title", "")
                }
                else
                {
                    var new_title = UpgradeBuilding.generateResourcesLabel(new_buildings[building_id]);
                    label.attr("title", new_title);
                    UI.ToolTip(label)
                }
            })
        })
    },
    hide_upgrade_buildings: function()
    {
        $('.empty').show();
        $('.can_upgrade').each(function()
        {
            $(this).unbind("click")
        });
        $('.can_upgrade').removeClass("can_upgrade");
        $('.upgrade_hammer').remove();
        $('.label_no_lvl').hide();
        $('.building_no_lvl').hide();
        UpgradeBuilding.upgrade_buildings_enabled = false;
        $.removeCookie('upgrade_buildings')
    },
    generateResourcesLabel: function(needed_resources, destroy)
    {
        var hours = Math.floor(needed_resources.time / 3600),
            minutes = Math.floor(needed_resources.time / 60) % 60,
            seconds = needed_resources.time % 60,
            timeString = hours + ":";
        if (minutes < 10) timeString += "0";
        timeString += minutes + ":";
        if (seconds < 10) timeString += "0";
        timeString += seconds;
        if (destroy && needed_resources.population > 0)
        {
            return s("Construction time: %1 <br/> free population: %2", timeString, needed_resources.population)
        }
        else if (destroy)
        {
            return s("Building time: %1", timeString)
        }
        else
        {
            var str = resource('wood', needed_resources.wood) + ' ' + resource('stone', needed_resources.stone) + ' ' + resource('iron', needed_resources.iron) + "<br />" + s("%1: %2", 'Villagers needed', needed_resources.population) + "<br />" + s("%1: %2", "Building time", timeString);
            return str
        }
    }
}

function resource(type, amount)
{
    return s("<span class='icon header %1'></span> %2", type, amount)
}