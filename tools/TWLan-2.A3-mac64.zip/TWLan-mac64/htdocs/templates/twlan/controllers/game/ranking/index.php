<h2>Ranking</h2>
<table width="100%">
    <tbody>
        <tr>
            <td valign="top" width="130px">
                <?php require('navi.php'); ?>
            </td>
            <td valign="top">
                <?php echo $content; ?>
            </td>
        </tr>
    </tbody>
</table>
