<?php namespace Twlan; ?>
<table width="100%">
    <tr>
        <td>
            <?php require 'queue.php';?>
            <?php require 'train.php';?>
        </td>
    </tr>
</table>