<script type="text/javascript" src="js/game/Snob.js"></script>

<table>
    <tbody>
        <tr>
        <td valign="top">
            <?php require('coin_navi.php'); ?>
        </td>
        <td valign="top">
            <?php require('coin_'.$mode.'.php'); ?>
        </td>
        </tr>
    </tbody>
</table>
