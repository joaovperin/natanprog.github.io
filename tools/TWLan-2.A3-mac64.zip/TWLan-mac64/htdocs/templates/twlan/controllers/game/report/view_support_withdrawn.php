<table class="vis" width="470">
    <tbody><tr>
        <td class="nopad">
        <table align="center" class="vis" width="100%" style="margin-top: -2px;">
    <tbody><tr>
        <td align="center" width="20%">
            <a href="/game.php?village=78919&amp;type=all&amp;mode=forward&amp;id=3120568&amp;screen=report">Forward</a>        </td>
                <td align="center" width="20%">
            <a href="/game.php?village=78919&amp;mode=all&amp;action=del_one&amp;h=f18e&amp;id=3120568&amp;screen=report">Delete</a>
        </td>
                
        <td align="center" width="20%">
                    </td>
        <td align="center" width="20%">
                        <a href="/game.php?village=78919&amp;mode=all&amp;view=3120519&amp;screen=report" id="report-prev" class="">
            <img src="graphic/list-down.png" style="vertical-align: -2px" alt="" class="">
            </a>
                    </td>
    </tr>
    <tr class="move_list" style="display:none">
        <td align="center" colspan="4">
            <form action="" method="POST">
                <select name="group_id">
                                    </select>
                <input class="btn" type="submit" value="Move">
            </form>
        </td>
    </tr>
</tbody></table>
        
            <table class="vis">
                <tbody><tr>
                                    <th width="140">Subject</th>
                                    <th width="400">
                                            
                        <span data-id="">
                            <span class="quickedit-content">
                                <span class="quickedit-label">
                                     windelwillis village has withdrawn their support based out of windelwillis village 3
                                </span>
                                                            </span>
                        </span>
                    </th>
                </tr>
                <tr>
                    <td>
                                                Sent
                                            </td>
                    <td>
                        Sep 21, 2014  16:19:41                  </td>
                </tr>
                                <tr>
                    <td colspan="2" valign="top" height="160" style="border: solid 1px black; padding: 4px;">
                        <table width="100%">
<tbody><tr><th width="60">From:</th><th><a href="/game.php?village=78919&amp;id=1444124&amp;screen=info_player">windelwilli</a></th></tr>
<tr><td>Village:</td><td><span class="village_anchor contexted" data-player="1444124" data-id="78919"><a href="/game.php?village=78919&amp;id=78919&amp;screen=info_village">windelwillis village (322|425) K43</a><a class="ctx" href="#"></a></span></td></tr>

<tr><th>To:</th><th><a href="/game.php?village=78919&amp;id=1444124&amp;screen=info_player">windelwilli</a></th></tr>
<tr><td>Village:</td><td><span class="village_anchor contexted" data-player="1444124" data-id="78922"><a href="/game.php?village=78919&amp;id=78922&amp;screen=info_village">windelwillis village 3 (320|423) K43</a><a class="ctx" href="#"></a></span></td></tr>
</tbody></table><br>

<h4>Units:</h4>
<table class="vis">
<tbody><tr>
                <th width="35"><img src="graphic/unit/unit_spear.png?48b3b" title="Spear fighter" alt="" class=""></th><th width="35"><img src="graphic/unit/unit_sword.png?b389d" title="Swordsman" alt="" class="faded"></th><th width="35"><img src="graphic/unit/unit_axe.png?51d94" title="Axeman" alt="" class="faded"></th><th width="35"><img src="graphic/unit/unit_archer.png?db2c3" title="Archer" alt="" class="faded"></th><th width="35"><img src="graphic/unit/unit_spy.png?eb866" title="Scout" alt="" class="faded"></th><th width="35"><img src="graphic/unit/unit_light.png?2d86d" title="Light cavalry" alt="" class="faded"></th><th width="35"><img src="graphic/unit/unit_marcher.png?ad3be" title="Mounted archer" alt="" class="faded"></th><th width="35"><img src="graphic/unit/unit_heavy.png?a83c9" title="Heavy cavalry" alt="" class="faded"></th><th width="35"><img src="graphic/unit/unit_ram.png?2003e" title="Ram" alt="" class="faded"></th><th width="35"><img src="graphic/unit/unit_catapult.png?5659c" title="Catapult" alt="" class="faded"></th><th width="35"><img src="graphic/unit/unit_snob.png?0019c" title="Nobleman" alt="" class="faded"></th>
    </tr>
<tr>
                <td class="unit-item">1</td><td class="unit-item hidden">0</td><td class="unit-item hidden">0</td><td class="unit-item hidden">0</td><td class="unit-item hidden">0</td><td class="unit-item hidden">0</td><td class="unit-item hidden">0</td><td class="unit-item hidden">0</td><td class="unit-item hidden">0</td><td class="unit-item hidden">0</td><td class="unit-item hidden">0</td>
    </tr>
</tbody></table>
                    </td>
                </tr>
            </tbody></table>
        <table align="center" class="vis" width="100%" style="margin-top: -2px;">
    <tbody><tr>
        <td align="center" width="20%">
            <a href="/game.php?village=78919&amp;type=all&amp;mode=forward&amp;id=3120568&amp;screen=report">Forward</a>        </td>
                <td align="center" width="20%">
            <a href="/game.php?village=78919&amp;mode=all&amp;action=del_one&amp;h=f18e&amp;id=3120568&amp;screen=report">Delete</a>
        </td>
                
        <td align="center" width="20%">
                    </td>
        <td align="center" width="20%">
                        <a href="/game.php?village=78919&amp;mode=all&amp;view=3120519&amp;screen=report" id="report-prev" class="">
            <img src="graphic/list-down.png" style="vertical-align: -2px" alt="" class="">
            </a>
                    </td>
    </tr>
    <tr class="move_list" style="display:none">
        <td align="center" colspan="4">
            <form action="" method="POST">
                <select name="group_id">
                                    </select>
                <input class="btn" type="submit" value="Move">
            </form>
        </td>
    </tr>
</tbody></table>
        </td>
    </tr>
</tbody></table>

<script>
    $(function(){
        $('.quickedit').QuickEdit( { url: TribalWars.buildURL('POST', 'report', { ajaxaction: 'edit_subject', report_id: '__ID__' } ) } );
    });
</script>