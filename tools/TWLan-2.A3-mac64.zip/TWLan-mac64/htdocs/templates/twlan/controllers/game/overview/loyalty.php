<?php //TODO Colors?>
<div class="vis_item"><?php echo floor($village->loyalty); ?></div>