<?php
require('header.php');
echo $content;
require('footer.php');
?>