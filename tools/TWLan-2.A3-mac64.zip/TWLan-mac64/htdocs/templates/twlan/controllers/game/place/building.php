<?php require('navi.php'); ?>
<?php if(!isset($reqMode)) require($mode.'.php'); else require($reqMode.'.php'); ?>
