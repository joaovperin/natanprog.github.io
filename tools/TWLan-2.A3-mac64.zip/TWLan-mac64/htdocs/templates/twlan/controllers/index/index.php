<?php 
namespace Twlan; 
?>
<!-- MAIN CONTENT -->
<section class="l-content">
    <div class="content-drop"></div>
    <div class="ornament ornament-top-right"></div>
    <div class="ornament ornament-top-left"></div>
    <div class="ornament ornament-bottom-left"></div>
    <div class="ornament ornament-bottom-right"></div>
    <div class="l-section-divider"></div>
    <div class="l-constrained">
        <div class="l-clearfix">
            <!--NEWS-->
            
            <!-- end .paged-content -->
            <!--GAME INFO-->

            <!-- end .paged-content -->
            <!-- pagination inyected via js -->
            <div id="pagination3" class="pagination l-center l-clearfix"></div>
        </div>
        <!--end .l-content-->
    </div>
    <!-- .l-constrained -->
</section>
