<?php namespace Twlan; ?>
<table id="content_value" class="inner-border main" cellspacing="0">
    <tr>
        <td>
            <h2><?php l('sidWrong.title2'); ?></h2>
            <p>
                <?php l('sidWrong.max', array('link' => '<a href="index.php" target="_top">'.ll('sidWrong.index').'</a>')); ?>
                <br />
                <a href="../index.php" target="_top"><?php l('sidWrong.link', array('t'=>'&raquo;'));?></a>
            </p>
        </td>
    </tr>
</table>