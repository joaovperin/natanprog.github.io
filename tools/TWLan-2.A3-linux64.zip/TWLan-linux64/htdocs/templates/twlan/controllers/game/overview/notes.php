<?php //TODO?>
<table width="100%">
    <tr style="display:none">
        <td id="village_note"></td>
    </tr>
    <tr>
        <td>
            <a id="edit_notes_link" href="#" onclick="editNotesPopup('game.php?village=<?php echo $vid;?>&amp;screen=overview&amp;ajaxaction=edit_notes_popup'); return false;">» bearbeiten</a>
        </td>
    </tr>
</table>