<?php namespace Twlan; ?>
/* 23706 trunk*/
/**/
function clone(obj)
{
    if (obj == null || typeof obj != 'object') return obj;
    var temp = new obj.constructor();
    for (var key in obj) temp[key] = clone(obj[key]);
    return temp
};
var TrainOverview = {
    train_link: '',
    cancel_link: '',
    pop_max: 0,
    is_affordability_forecasting_initialized: false,
    focused_input_id: null,
    single_village_mode: false,
    init: function()
    {
        $('#train_form').submit(function(event)
        {
            event.preventDefault();
            TrainOverview.submitOrder($('#train_form')[0])
        })
    },
    initMassOverview: function()
    {
        TrainOverview.recalcPop();
        $('#mr_all_form .unit_input_field').change(function()
        {
            TrainOverview.recalcPop()
        })
    },
    initSingleVillageMode: function()
    {
        this.single_village_mode = true;
        if (!this.is_affordability_forecasting_initialized)
        {
            $(window.TribalWars).on('resource_change', function()
            {
                unit_build_block.dat.res.wood = game_data.village.wood;
                unit_build_block.dat.res.stone = game_data.village.stone;
                unit_build_block.dat.res.iron = game_data.village.iron;
                setTimeout(function()
                {
                    unit_build_block._onchange();
                    unit_build_block.forecastAffordability()
                }, 1)
            });
            $(document).on('partial_reload_start', function()
            {
                unit_build_block.updateURLForFilledUnits();
                TrainOverview.focused_input_id = $(':focus').attr('id')
            });
            $(document).on('partial_reload_end', function()
            {
                var focused_input = $('#' + TrainOverview.focused_input_id)[0];
                if (focused_input)
                {
                    focused_input.focus();
                    if (focused_input.setSelectionRange)
                    {
                        focused_input.setSelectionRange(5, 5)
                    }
                    else $(focused_input).val(focused_input.value)
                }
            });
            this.is_affordability_forecasting_initialized = true
        }
    },
    recalcPop: function()
    {
        var popuplation_sum = 0;
        $('#mr_all_form .unit_input_field').each(function()
        {
            var input = $(this),
                count = parseInt(input.val(), 10);
            if (count > 0)
            {
                var unit_id = input.attr("name");
                popuplation_sum += count * unit_managers.units[unit_id].pop
            }
        });
        var pop_span = $('#pop_cost');
        if (popuplation_sum > 24e3)
        {
            pop_span.addClass('red')
        }
        else pop_span.removeClass('red');
        pop_span.text(popuplation_sum)
    },
    submitOrder: function()
    {
        var units = {},
            submit_buttons = $("#train_form input[type='submit']");
        $.each($('.recruit_unit'), function()
        {
            var field = $(this),
                value = parseInt(field.val(), 10);
            if (field.val() > 0)
            {
                var unit_id = field.attr('id').replace("_0", "");
                units[unit_id] = value
            }
        });
        if (units.length == 0) return;
        submit_buttons.attr("disabled", 'disabled');
        TribalWars.post(TrainOverview.train_link,
        {},
        {
            units: units
        }, function(data)
        {
            setTimeout(function()
            {
                submit_buttons.removeAttr('disabled')
            }, 500);
            if (data.success) $('.recruit_unit').val('');
            TrainOverview.updateAll(data);
            if (mobile) initMobileMove();
            if (data.error)
            {
                UI.ErrorMessage(data.error)
            }
            else if (data.msg) UI.SuccessMessage(data.msg);
            if (mobile) UI.SuccessMessage('The recruitment order was successfully queued.')
        }, function()
        {
            submit_buttons.removeAttr('disabled')
        })
    },
    cancelOrder: function(id)
    {
        TribalWars.post(TrainOverview.cancel_link,
        {},
        {
            id: id
        }, function(data)
        {
            if (data.error)
            {
                UI.ErrorMessage(data.error);
                return
            };
            TrainOverview.updateAll(data);
            $('.recruit_unit').val('')
        }, 'json');
        return false
    },
    updateAll: function(data)
    {
        var queue_wrapper = $('.current_prod_wrapper');
        if (queue_wrapper.length == 1)
        {
            if (data.current_order)
            {
                queue_wrapper.replaceWith(data.current_order)
            }
            else queue_wrapper.remove()
        }
        else
        {
            $('.current_prod_wrapper').remove();
            $('#train_form').before(data.current_order)
        };
        if (typeof unit_build_block != 'undefined' && typeof data.resources != 'undefined')
        {
            unit_build_block.dat.res = {
                wood: data.resources[0],
                stone: data.resources[1],
                iron: data.resources[2],
                pop: TrainOverview.pop_max - data.population
            };
            unit_build_block._onchange();
            if (this.single_village_mode) unit_build_block.forecastAffordability()
        };
        if (typeof data.decommission != 'undefined') $.each(data.decommission, function(unit_id, available)
        {
            unit_managers.units[unit_id] = available;
            var link = unit_build_block.get_a(unit_id);
            if (link) link.innerHTML = "(" + available + ")"
        });
        startTimer()
    }
}

function UnitBuildManager(village_id, dat)
{
    this.decommission = !dat ? true : false;
    this.village_id = village_id;
    this.dat = dat;
    this._progress = false;
    this.cur_res = clone(dat.res);
    this._onchange = function()
    {
        if (this.decommission) return;
        if (this._progress || UnitBuildManager._disabled) return;
        this._progress = true;
        this._calc_cur_res();
        var res = this.cur_res,
            is_over = (res.wood < 0 || res.stone < 0 || res.iron < 0 || res.pop < 0);
        for (var unit_id in unit_managers.units)
        {
            if (!unit_managers.units.hasOwnProperty(unit_id)) continue;
            var amount = this.unit_max(unit_id),
                link = this.get_a(unit_id);
            if (link) link.innerHTML = "(" + amount + ")";
            var box = this.get_box(unit_id);
            if (!box)
            {
                continue
            }
            else if (is_over)
            {
                box.style.color = 'red'
            }
            else box.style.color = 'black'
        };
        this._progress = false;
        if (TrainOverview.single_village_mode) this.previewCosts()
    };
    this.forecastAffordability = function()
    {
        for (var unit_id in unit_managers.units)
        {
            if (!unit_managers.units.hasOwnProperty(unit_id) || !unit_managers.units[unit_id].requirements_met) continue;
            var $input = $(this.get_unit_interaction(unit_id)),
                $afford_hint = $(this.get_unit_afford_hint(unit_id)),
                $blocked_hint = $(this.get_unit_blocked_hint(unit_id)),
                afford = this.canAffordUnit(unit_id);
            if ($blocked_hint.length !== 0)
            {
                $input.hide();
                $afford_hint.hide()
            }
            else if (afford.afford === Village.AFFORD_TYPE_NOW)
            {
                $input.show();
                $afford_hint.hide()
            }
            else
            {
                $input.hide();
                $afford_hint.html(afford.when).show();
                if (afford.afford == Village.AFFORD_TYPE_COUNTDOWN) Timing.tickHandlers.timers.reset()
            }
        }
    };
    this.updateURLForFilledUnits = function()
    {
        var url = document.location.href;
        if (url.substr(-1) === '#') url = url.substr(0, url.length - 1);
        for (var unit_id in unit_managers.units)
        {
            if (!unit_managers.units.hasOwnProperty(unit_id) || !unit_managers.units[unit_id].requirements_met) continue;
            var uri_regex = new RegExp(unit_id + '=[0-9]{1,}'),
                count = Number(this.get_box(unit_id).value);
            if (url.match(uri_regex))
            {
                url = url.replace(uri_regex, unit_id + '=' + count)
            }
            else url += '&' + unit_id + '=' + count
        };
        if (Modernizr.history) history.replaceState(
        {}, '', url)
    };
    this.previewCosts = function()
    {
        for (var unit_id in unit_managers.units)
        {
            if (!unit_managers.units.hasOwnProperty(unit_id) || !unit_managers.units[unit_id].requirements_met) continue;
            var unit_count = Number(this.get_box(unit_id).value);
            if (!unit_count) unit_count = 1;
            this.setUnitCostDisplay(unit_id, unit_count)
        }
    }, this.setUnitCostDisplay = function(unit_id, count)
    {
        var unit = unit_managers.units[unit_id],
            $costs = {
                wood: $('#' + unit_id + '_' + this.village_id + '_cost_wood'),
                stone: $('#' + unit_id + '_' + this.village_id + '_cost_stone'),
                iron: $('#' + unit_id + '_' + this.village_id + '_cost_iron'),
                pop: $('#' + unit_id + '_' + this.village_id + '_cost_pop'),
                time: $('#' + unit_id + '_' + this.village_id + '_cost_time')
            };
        $costs.wood.html(count * unit.wood);
        $costs.stone.html(count * unit.stone);
        $costs.iron.html(count * unit.iron);
        $costs.pop.html(count * unit.pop);
        $costs.time.html(Format.buildTime(count * unit.build_time * 1e3, true));
        var resources = ['wood', 'stone', 'iron'];
        for (var i = 0; i < resources.length; i++)
        {
            var res = resources[i];
            if (count * unit[res] > game_data.village[res])
            {
                $costs[res].addClass('warn')
            }
            else $costs[res].removeClass('warn')
        };
        if (count * unit.pop > game_data.village.pop_max - game_data.village.pop)
        {
            $costs.pop.addClass('warn')
        }
        else $costs.pop.removeClass('warn')
    }, this.unit_max = function(unit)
    {
        if (this.decommission) return unit_managers.units[unit];
        var amount = 999999;
        for (var res in this.cur_res)
        {
            if (!this.cur_res.hasOwnProperty(res)) continue;
            amount = Math.min(amount, Math.floor(this.cur_res[res] / unit_managers.units[unit][res]))
        };
        if (amount < 0) return 0;
        return amount
    };
    this.canAffordUnit = function(unit_id)
    {
        var unit = unit_managers.units[unit_id];
        return Village.canAfford(unit.wood, unit.stone, unit.iron)
    };
    this._input_value = function(input)
    {
        var amount = parseInt(input.value, 10);
        if (isNaN(amount) || amount < 0) amount = 0;
        if (amount != parseInt(input.value, 10)) input.value = (amount > 0 ? amount : '');
        return amount
    };
    this._calc_cur_res = function()
    {
        this.cur_res = clone(this.dat.res);
        for (var unit_id in unit_managers.units)
        {
            if (!unit_managers.units.hasOwnProperty(unit_id)) continue;
            var box = this.get_box(unit_id);
            if (!box || box.disabled) continue;
            var amount = this._input_value(box);
            for (var res in this.cur_res)
            {
                if (!this.cur_res.hasOwnProperty(res)) continue;
                this.cur_res[res] -= amount * unit_managers.units[unit_id][res]
            }
        };
        return
    };
    this.set_max = function(unit)
    {
        if (UnitBuildManager._disabled) return;
        var el = this.get_box(unit);
        if (!el) return;
        var max_amount = this.unit_max(unit),
            curr_amount = this._input_value(el);
        if (this.decommission)
        {
            el.value = max_amount;
            return
        };
        if (max_amount == 0)
        {
            el.value = ''
        }
        else el.value = max_amount += curr_amount;
        this._onchange()
    };
    this.get_box = function(unit)
    {
        return document.getElementById(unit + '_' + this.village_id)
    };
    this.get_a = function(unit)
    {
        return document.getElementById(unit + '_' + this.village_id + '_a')
    };
    this.get_unit_interaction = function(unit)
    {
        return document.getElementById(unit + '_' + this.village_id + '_interaction')
    };
    this.get_unit_afford_hint = function(unit)
    {
        return document.getElementById(unit + '_' + this.village_id + '_afford_hint')
    };
    this.get_unit_blocked_hint = function(unit)
    {
        return document.getElementById(unit + '_' + this.village_id + '_blocking_hint')
    };
    var _t = this;
    for (var unit in unit_managers.units)
    {
        var box = this.get_box(unit);
        if (box)
        {
            box.onchange = function()
            {
                _t._onchange()
            };
            box.onkeyup = function()
            {
                _t._onchange()
            }
        }
    }
}

function doMRFill(use_max_amount, insert_diff)
{
    var global_order = {},
        order_cnt = 0,
        ell = $("input[id^='unit_input_']");
    ell.each(function(i)
    {
        var unit_id = ell[i].name,
            amount = parseInt(ell[i].value, 10);
        if (use_max_amount && amount > 0)
        {
            global_order[unit_id] = amount * 24e3;
            order_cnt++
        }
        else if (isNaN(amount))
        {
            ell[i].value = '0'
        }
        else if (amount > 0)
        {
            global_order[unit_id] = amount;
            order_cnt++
        }
    });
    if (!order_cnt) return false;
    var buffer_res = {},
        resources = {
            wood: 0,
            stone: 0,
            iron: 0,
            pop: 0
        };
    for (var res_id in resources)
        if (resources.hasOwnProperty(res_id)) buffer_res[res_id] = $("input[name='buffer_" + res_id + "']").val();
    for (var village_id in unit_managers)
    {
        if (village_id == "units") continue;
        var unit_manager = unit_managers[village_id],
            order = clone(global_order),
            order_res = {
                wood: 0,
                stone: 0,
                iron: 0,
                pop: 0
            };
        for (var unit_id in order)
        {
            var box = unit_manager.get_box(unit_id);
            if (!box) continue;
            if (insert_diff)
            {
                var el = $(box),
                    existing, new_amount, running;
                if ((existing = el.data('existing')))
                {
                    new_amount = Math.max(0, order[unit_id] - existing);
                    order[unit_id] = new_amount
                };
                if ((running = el.data('running')))
                {
                    new_amount = Math.max(0, order[unit_id] - running);
                    order[unit_id] = new_amount
                }
            };
            if (!box.disabled)
            {
                var units = unit_managers.units[unit_id];
                for (var res in units)
                    if (units.hasOwnProperty(res)) order_res[res] += units[res] * order[unit_id]
            }
        };
        var max_amount = 999999,
            max_res;
        for (var res in order_res)
        {
            max_res = Math.max(0, unit_manager.dat.res[res] - buffer_res[res]);
            max_amount = Math.min(max_amount, max_res / order_res[res])
        };
        if (max_amount > 1) max_amount = 1;
        for (var unit_id in order)
            if (unit_manager.get_box(unit_id).disabled)
                if (use_max_amount)
                {
                    order[unit_id] = 0
                }
                else continue;
        for (var unit_id in unit_managers.units)
        {
            var el = unit_manager.get_box(unit_id);
            if (!el || el.disabled)
            {
                continue
            }
            else if (order[unit_id])
            {
                var max_possible = Math.floor(max_amount * order[unit_id]);
                el.value = max_possible
            }
            else el.value = '0'
        };
        unit_manager._onchange()
    };
    return false
}

function doMDFill(down_to)
{
    var ell = $("input[id^='unit_input_']"),
        wanted = {};
    ell.each(function(i)
    {
        var unit_id = ell[i].name;
        wanted[unit_id] = parseInt(ell[i].value, 10)
    });
    $('.unit_entry').not(':disabled').each(function()
    {
        var $this = $(this),
            unit_id = $this.attr('id').split('_')[0],
            max = parseInt($this.data('max'));
        if (!down_to)
        {
            $this.val(max > wanted[unit_id] ? wanted[unit_id] : max)
        }
        else
        {
            var existing = parseInt($this.data('existing')),
                running = $this.data('running') ? parseInt($this.data('running')) : 0,
                remove = existing - running - wanted[unit_id];
            if (remove > 0)
            {
                $this.val(max > remove ? remove : max)
            }
            else $this.val(0)
        }
    })
}

    function MDSetBuffer(url)
    {
        var units = $('#mr_all_form').serialize();
        $.ajax(
        {
            type: 'POST',
            url: url,
            data: units,
            success: function ()
            {
                UI.SuccessMessage("D Istellige si gspeicheret worde")
            }
        })
    }