<?php 
if ($user == '') require("container_index.php");
else require("container_post.php");