<?php
namespace Twlan;
?>
<table id="content_value" class="inner-border main" cellspacing="0">
    <tr>
        <td>
            <h3><?php echo l('createVillage.title');?></h3>
            <div id="error" class="error" style="line-height: 20px"><?php echo $error;?></div>
        </td>
    </tr>
</table>