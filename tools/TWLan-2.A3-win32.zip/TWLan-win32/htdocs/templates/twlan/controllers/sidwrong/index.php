<?php namespace Twlan; ?>
<table id="content_value" class="inner-border main" cellspacing="0">
    <tr>
        <td>
            <h2><?php l('sidWrong.title'); ?></h2>
            <p><?php l('sidWrong.content', array('link' => '<a href="../index.php" target="_top">'.ll('sidWrong.index').'</a>')); ?></p>
        </td>
    </tr>
</table>