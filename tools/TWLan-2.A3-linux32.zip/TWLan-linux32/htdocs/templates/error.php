<!-- error -->
<?php if (isset($_error)) echo "<div class=\"error\">".$_error."</div>"; ?>