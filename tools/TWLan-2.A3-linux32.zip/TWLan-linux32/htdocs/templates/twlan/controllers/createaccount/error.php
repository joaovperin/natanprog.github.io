<?php
namespace Twlan;
?>
<table id="content_value" class="inner-border main" cellspacing="0">
    <tr>
        <td>
            <h1><img src="graphic/rabe_38x40.png" alt="" /> <?php echo l('join.title');?></h1>
            <div id="error" class="error" style="line-height: 20px"><?php echo $error;?></div>
        </td>
    </tr>
</table>