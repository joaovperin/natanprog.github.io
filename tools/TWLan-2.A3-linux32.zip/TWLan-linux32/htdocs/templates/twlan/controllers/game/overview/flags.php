<?php //TODO?>
<table class="vis" width ="100%">
    <tr>
        <td>
            <a href="game.php?village=<?php echo $vid;?>&amp;screen=flags"><img src="graphic/flags/medium/4_9.png" alt="" style="float: left; width: 30px; height: 30px" /></a>
        </td>
        <td style="font-size: 0.8em">
            <strong>Verteidigungsstärke</strong>
            <p>+2% Verteidigungsstärke</p>
        </td>
    </tr>
</table>