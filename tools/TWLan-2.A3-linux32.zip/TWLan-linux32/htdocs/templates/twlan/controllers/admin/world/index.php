<?php
namespace TWLan;
?>
<b>TODO</b>
<?php /*<div class="widget">
    <div class="widget-header">
    <?php l('admin.world.generalInfo'); ?>
    </div>
    <div class="widget-body">
        <div class="widget-content col-xs-6">
            <div class="widget-icon green pull-left ng-scope">
                <i class="glyphicon glyphicon-user"></i>
            </div>
            <div class="title ng-scope"><?php echo $world->numPlayers(); ?>
            </div>
            <div class="comment ng-scope"><?php l('admin.world.players'); ?></div>
        </div>
        <div class="widget-content col-xs-6">
            <div class="widget-icon red pull-left ng-scope">
                <i class="glyphicon glyphicon-home"></i>
            </div>
            <div class="title ng-scope"><?php echo Model\World\Village::q()->count(); ?>
            </div>
            <div class="comment ng-scope"><?php l('game.villages'); ?></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>*/ ?>
