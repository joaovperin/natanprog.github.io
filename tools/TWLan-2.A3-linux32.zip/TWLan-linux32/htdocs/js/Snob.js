<?php namespace Twlan; ?>
/* 23706 trunk*/
/*1fcfa7f973c3acab1f748ef920d3f212*/
Snob = {
    Memory:
    {
        sumCoins: 0
    },
    init: function() {},
    Coin:
    {
        init: function()
        {
            $(".mint_multi_button").click(function()
            {
                Snob.Coin.multiCoin()
            });
            $(".coin_amount").change(function()
            {
                Snob.Coin.syncInputs(this)
            });
            $(".select_coins").change(function()
            {
                Snob.Coin.recalcBunches();
                Snob.Coin.enableMinting()
            });
            $("#select_anchor_top, #select_anchor_bottom").click(function()
            {
                Snob.Coin.setCoinAmount();
                Snob.Coin.enableMinting()
            })
        },
        syncInputs: function(value)
        {
            $('select[name^="coin_amount"]').val($(value).val())
        },
        setCoinAmount: function()
        {
            Snob.Memory.sumCoins = 0;
            var amount = parseInt($('select[name^="coin_amount"]').val());
            $("select[name^='id_']").each(function()
            {
                var count_options = $(this).children().length - 1,
                    selectAt = 0;
                if (amount < 0)
                {
                    selectAt = count_options + amount;
                    if (selectAt < 0) selectAt = 0
                }
                else if (count_options < amount)
                {
                    selectAt = count_options
                }
                else selectAt = amount;
                $(this).children().each(function(index)
                {
                    if (index == selectAt)
                    {
                        Snob.Memory.sumCoins += selectAt;
                        $(this).prop('selected', true)
                    }
                })
            });
            Snob.Coin.setBunches(Snob.Memory.sumCoins);
            Snob.Memory.sumCoins = 0
        },
        recalcBunches: function()
        {
            var sum = 0;
            $("select[name^='id_']").each(function()
            {
                sum += parseInt($(this).val())
            });
            Snob.Coin.setBunches(sum)
        },
        setBunches: function(amount)
        {
            $('#selectedBunches_top').text(amount);
            $('#selectedBunches_bottom').text(amount)
        },
        enableMinting: function()
        {
            $(".mint_multi_button").removeAttr("disabled")
        },
        multiCoin: function()
        {
            var villages = {},
                val, village_id, inputs = $('.select_coins');
            inputs.each(function(i, input)
            {
                input = $(input);
                val = input.val();
                if (val > 0)
                {
                    village_id = input.attr("name").replace(/id_/, '');
                    villages[village_id] = parseInt(val, 10)
                }
            });
            $('.mint_multi_button').attr("disabled", "disabled");
            $.ajax(
            {
                url: Snob.Coin.coin_multi_link,
                type: 'post',
                dataType: 'json',
                data:
                {
                    villages: villages
                },
                success: function(data)
                {
                    var minted = 0,
                        gold_cost = data.gold_cost;
                    $('.mint_multi_button').attr("disabled", "");
                    if (data.error)
                    {
                        UI.ErrorMessage(data.error);
                        return
                    };
                    $.each(data.minted_coins, function(village_id, coins_minted)
                    {
                        minted += coins_minted;
                        var select = $('#id_' + village_id),
                            options = select.find("option"),
                            max_coins = (options.length - 1) - coins_minted;
                        $.each(options, function(i, option)
                        {
                            option = $(option);
                            val = option.val();
                            if (val > 0 && val > max_coins) option.remove()
                        });
                        if (select.find("option").length <= 1) select.remove();
                        var res = $('#village_' + village_id).find(" .resources"),
                            span, new_res, current_res;
                        $.each(gold_cost[village_id], function(res_nr, cost)
                        {
                            span = $(s('span:eq(%1)', res_nr), res);
                            current_res = parseInt(span.text().replace(/\./g, ''));
                            new_res = current_res - cost;
                            var formatted_res = number_format(new_res, ".");
                            span.text(formatted_res);
                            span.removeClass("warn").removeClass("warn_90").addClass("res")
                        })
                    });
                    Snob.Coin.recalcBunches();
                    UI.InfoMessage(data.message, 1e3);
                    Snob.Coin.enableMinting()
                }
            })
        }
    }
}